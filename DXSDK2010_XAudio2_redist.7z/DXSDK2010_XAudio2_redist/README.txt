These files are from DirectX SDK. Install this for Win7 and older versions.
Run DXSETUP.exe
Win8/Win10 natively supports XAudio2.

www.qtav.org